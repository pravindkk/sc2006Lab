import { StyleSheet, Text, View } from 'react-native'
import { React, useEffect, useState } from 'react'
import { searchChats } from '../../controller/Search';

const SearchChatsScreen = () => {

  return (
    <View>
      <Text>SearchChatsScreen</Text>
    </View>
  )
}

export default SearchChatsScreen;

const styles = StyleSheet.create({})