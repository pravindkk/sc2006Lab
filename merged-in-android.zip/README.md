# sc2006Lab
Put all coding here
