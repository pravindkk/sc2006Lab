dialog map info here
