export const FitnessImg = [
    "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse1.mm.bing.net%2Fth%3Fid%3DOIP.cnvN4gAdAP3R2fiSFcCt9gHaE1%26pid%3DApi&f=1&ipt=bde0eded295fb10fd3235eaa1267116e9a729eb82bded1a46b45586962c70b89&ipo=images",
    "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fimages2.alphacoders.com%2F106%2Fthumb-1920-1064135.jpg&f=1&nofb=1&ipt=c12bd8747afd346b2930f1d64172a47d07393f8efd5c0313a2cc3a8b21885689&ipo=images",
    "https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F35%2F2014%2F03%2F25191223%2FGettyImages-1049840750.jpg&f=1&nofb=1&ipt=a75f8f9b43ff923c739aa1e17798be40edf514bc71842b26b51679bf001dcbec&ipo=images",

]