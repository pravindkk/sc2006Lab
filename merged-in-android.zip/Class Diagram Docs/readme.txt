Upload class diagram here
