import { StyleSheet, Text, View } from 'react-native'
import { React, useEffect, useState } from 'react'
import { searchGyms } from '../../controller/Search';

const SearchGymsScreen = () => {

  return (
    <View>
      <Text>SearchGymsScreen</Text>
    </View>
  )
}

export default SearchGymsScreen;

const styles = StyleSheet.create({})