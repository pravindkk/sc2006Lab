PDF copy of Lab 1, 2, 3 ,4, 5 submission
