import { StyleSheet, Text, View } from 'react-native'
import { React, useEffect, useState } from 'react'
import { searchWorkouts } from '../../controller/Search';

const SearchWorkoutsScreen = () => {

  return (
    <View>
      <Text>SearchWorkoutsScreen</Text>
    </View>
  )
}

export default SearchWorkoutsScreen;

const styles = StyleSheet.create({})