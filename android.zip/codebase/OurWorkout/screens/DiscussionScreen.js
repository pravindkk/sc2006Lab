import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const DiscussionScreen = () => {
  return (
    <View>
      <Text>DiscussionScreen</Text>
    </View>
  )
}

export default DiscussionScreen

const styles = StyleSheet.create({})